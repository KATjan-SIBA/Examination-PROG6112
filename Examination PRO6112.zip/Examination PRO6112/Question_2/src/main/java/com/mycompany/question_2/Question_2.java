/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question_2;


import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author jansi
 * 
**/


public class Question_2 {
    //windows settings 
    setTitle("Product App");
    setSize(450,500);
    setDefaultCloseOperations("Product App");
    setLayout(null);
    
   
    //Global declaration
    JButton btnProcessData;
    JtextField custumerName;
    JComboBox<String>productBox;
    JtextField price;
    JLabel lblPrice;
    JLabel lblProduct;
    JLabel lblCustomerName;
    
    
    public Question_2(){
    
    //intialize components
    
    //MenuBar
    JMenuBar menuBar =new JMenuBar();
    
    JMenu menuFile =new JMenu('File');
    JMenu menuEdit =new JMenu('Edit');
    
    menuBar.add(menuFile);
    menuBar.add(Edit);
    
    //Process button
    btnProcessData = new JButton ("PROCESS");
    btnProcessData.setBounds(35,45,270,25);
    
    
    //Text Fields
    Jlabel lblCustomerName = new Jlabel("Customer Name:");
    lblCustomerName.setBounds(30,90,140,25);
    Jlabel lblCustomerName = new Jlabel("Enter Price:");
    lblCustomerName.setBounds(30,90,140,25);
    
    //Drop down 
    JLabel lblProduct=   new JLabel("Select Product");
    lblProduct.setBounds(30,30,120,23);
    add(lblProduct);
    add(productBox); 
    
    
 
    }
    
    
    }
            
    }
  
 
    

    public static void main(String[] args) {
        
    }

    private static class JtextField {

        public JtextField() {
        }
    }
}
