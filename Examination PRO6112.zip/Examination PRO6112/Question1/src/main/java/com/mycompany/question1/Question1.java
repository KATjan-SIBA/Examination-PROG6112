/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



package com.mycompany.question1;



import java.util.Scanner;
/**
 *
 * @author jansi
 */
public class Question1 {
    
    //Interface for calculations
    public interface IProduct {
       int GetTotalProductsSold();
       double GetAverageProductSold();
       String GetMostPopularProduct();
    }
    
    //Two-dimenstion Arrays for the sales
    static int[][] sales ={
        {25,18,20},
        {15,10,20},
        {18,15,20}
    };
    
    // One-dimenstion Array for the product
    static String[] product={"Cozy Nights Monarch mattress","Restonic Barbados mattress","Sealy Phuket mattress" };
    
    abstract class Product implements IProduct{
         
        //Total product sold
        public int ProductSales (int[][] sales){
          int Total =0;
          int rowIndex=1;
          
          for (int i =0; i<sales[rowIndex].length;i++){
                Total =+sales[rowIndex][i] ; 
          }
            return Total;   
        }
        
        //Average Total
        public double AverageSales(int[][] sales){
           int total = ProductSales(sales);
           int count =0;
           
           //count the total number of elements in the 2d array
           for (int[] sale:sales){
               count += sale.length;  
           }
             retrun count == 0.0 :(double) total / count;
        }
        
        //Most popular
        public String MostPopularProduct(int [][] sales){
           String MostPopular;
     
        }
        
    }
    
        }

    public static void main(String[] args) {
        
        //Prompt user to enter data
        Scanner scanner = new Scanner(System.in);
        
        int sales = scanner.nextInt();
        
        //Data for cozy mattress
        System.out.println("Enter number of sales for month 1 for Cozy Nights Monarch mattress:");
        System.out.println("Enter number of sales for month 2 for Cozy Nights Monarch mattress:");
        System.out.println("Enter number of sales for month 3 for Cozy Nights Monarch mattress:");
        
        //Restonic Barbados mattress
        System.out.println("Enter number of sales for month 1 for Restonic Barbados mattress:");
        System.out.println("Enter number of sales for month 2 for Restonic Barbados mattress:");
        System.out.println("Enter number of sales for month 3 for Restonic Barbados mattress:");
        
        //Restonic Barbados mattress
        System.out.println("Enter number of sales for month 1 for Sealy Phuket mattress:");
        System.out.println("Enter number of sales for month 2 for Sealy Phuket m mattress:");
        System.out.println("Enter number of sales for month 3 for Sealy Phuket m mattress:");
        
        
       //Display
       System.out.println("TOTAL PRODUCT SALES" + Total);
       System.out.println("AVERAGE PRODUCT SALES" + AverageSales);
       System.out.println("MOST POPULAR" + GetMostPopularProduct);
       
       
        
    }
}
